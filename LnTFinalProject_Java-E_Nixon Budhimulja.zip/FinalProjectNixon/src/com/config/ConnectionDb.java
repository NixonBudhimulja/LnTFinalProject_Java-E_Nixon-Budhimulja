package com.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionDb {
	
	public Connection connect;
	public Statement statement;
	public ResultSet rs;
	public ResultSetMetaData rsMetaData;
	public PreparedStatement ps;
	
	public ConnectionDb() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/clothify", "root", "");
			statement = connect.createStatement();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public ResultSet getPuddingData() {
		try {
			ps = connect.prepareStatement("SELECT * FROM Pudding");
			rs = ps.executeQuery();
			rsMetaData = rs.getMetaData();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	public void insertPuddingData(String name, String kode, String stock, int price) {
		try {
			ps = connect.prepareStatement("INSERT INTO Pudding (Pudding_name, Pudding_kode, Pudding_stock, Pudding_price) VALUES (?,?,?,?)");
			ps.setString(1, name);
			ps.setString(2, kode);
			ps.setString(3, stock);
			ps.setInt(4, price);
			
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updateClothesData(int id, String name, String kode, String stock, int price) {
		try {
			ps = connect.prepareStatement("UPDATE Pudding SET Pudding_name = ?, Pudding_kode = ?, Pudding_stock = ?, Pudding_price = ? WHERE Pudding_id = ?");
			
			ps.setString(1, name);
			ps.setString(2, kode);
			ps.setString(3, stock);
			ps.setInt(4, price);
			ps.setInt(5, id);
			
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteClothesData(int id) {
		try {
			ps = connect.prepareStatement("DELETE FROM Pudding WHERE Pudding_id = ?");
			ps.setInt(1, id);
			
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
