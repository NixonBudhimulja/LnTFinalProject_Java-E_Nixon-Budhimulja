package com.project;

import java.util.Vector;

import com.config.ConnectionDb;
import com.utility.Clothes;

public class Main {
	
	public Vector<Pudding> PuddingData = new Vector<Pudding>();
	private ConnectionDb connectDb;
	
	public Main() {
		connectDb = new ConnectionDb();
		new Menu(PuddingData, connectDb);
	}

	public static void main(String[] args) {
		new Main();
	}

}
