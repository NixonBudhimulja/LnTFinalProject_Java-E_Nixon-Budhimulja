package com.project;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.config.ConnectionDb;
import com.utility.pudding;

public class Menu extends JFrame implements ActionListener{
	
	public Vector<Pudding> clothesData;
	private ConnectionDb connectDb;
	
	private JPanel topPanel, botPanel;
	private JLabel titleLbl;
	private JButton enterBtn;
	
	void menuView() {
		// Top Panel
		topPanel = new JPanel();
		titleLbl = new JLabel("Pudding");
		titleLbl.setFont(new Font("", Font.BOLD, 64));
		topPanel.add(titleLbl);
		
		// Bot Panel
		botPanel = new JPanel();
		enterBtn = new JButton("Enter");
		enterBtn.addActionListener(this);
		botPanel.add(enterBtn);
		
		add(topPanel, BorderLayout.NORTH);
		add(botPanel, BorderLayout.SOUTH);
	}
	
	void menuFrame() {
		setTitle("Pudding");
		setSize(350, 300);
		setVisible(true);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public Menu(Vector<Pudding> PuddingData, ConnectionDb connectDb) {
		this.PuddingData  = PuddingData;
		this.connectDb = connectDb;
		
		fillDataVector();
		menuView();
		menuFrame();
	}
	
	private void fillDataVector() {
		connectDb.rs = connectDb.getPuddingData();
		try {
			while (connectDb.rs.next()) {
				int id = Integer.valueOf(String.valueOf(connectDb.rs.getObject(1)));
				String name = String.valueOf(connectDb.rs.getObject(2));
				String kode = String.valueOf(connectDb.rs.getObject(3));
				String stock = String.valueOf(connectDb.rs.getObject(4));
				int price = Integer.valueOf(String.valueOf(connectDb.rs.getObject(5)));
				
				clothesData.add(new Clothes(id, name, kode, stock, price));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == enterBtn) {
			new tableClothes(clothesData, connectDb);
			setVisible(false);
		}
	}
	
}