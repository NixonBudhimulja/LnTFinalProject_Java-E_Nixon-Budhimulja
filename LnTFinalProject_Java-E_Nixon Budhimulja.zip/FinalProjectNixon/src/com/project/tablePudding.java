package com.project;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.MouseInputListener;

import com.config.ConnectionDb;
import com.utility.pudding;

public class tablepudding extends JFrame implements ActionListener, MouseInputListener{
	
	public Vector<pudding> puddingData;
	private ConnectionDb connectDb;
	
	private JPanel topPanel, midPanel, contentPanel, formPanel, tablePanel, botPanel, botTPanel, botBPanel,
		idLblPanel, nameLblPanel, brandLblPanel, sizeLblPanel, priceLblPanel,
		idFieldPanel, nameFieldPanel, brandFieldPanel, sizeFieldPanel, priceFieldPanel;
	private JLabel titleLbl, idLbl, nameLbl, brandLbl, sizeLbl, priceLbl;
	private JTextField idField, nameField, brandField, sizeField, priceField;
	private JTable puddingTable;
	private JScrollPane scrollPane;
	private JButton addBtn, updateBtn, deleteBtn, clearBtn, backBtn;
	
	private Vector<Object> column, row;
	private Vector<Vector<Object>> data;
	
	private int price;
	private String name, stock, kode, priceStr;
	
	public tablepudding(Vector<pudding> puddingData, ConnectionDb connectDb) {
		this.puddingData = puddingData;
		this.connectDb = connectDb;
		
		puddingView();
		puddingFrame();
	}
	
	void puddingView() {
		
		// Top Panel
		topPanel = new JPanel();
		titleLbl = new JLabel("CRUD pudding");
		titleLbl.setFont(new Font("", Font.BOLD, 48));
		topPanel.add(titleLbl);
		
		// Mid Panel
		midPanel = new JPanel();
		contentPanel = new JPanel(new GridLayout(1, 2));
		
		// Left Panel
		formPanel = new JPanel(new GridLayout(5, 2));
		
		// pudding ID
		idLblPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		idFieldPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		
		idLbl = new JLabel("ID :");
		idLblPanel.add(idLbl);
		idField = new JTextField();
		idField.setEditable(false);
		idField.setPreferredSize(new Dimension(150, 25));
		idFieldPanel.add(idField);
		
		// pudding Name
		nameLblPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		nameFieldPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		
		nameLbl = new JLabel("Name :");
		nameLblPanel.add(nameLbl);
		nameField = new JTextField();
		nameField.setPreferredSize(new Dimension(150, 25));
		nameFieldPanel.add(nameField);
		
		// pudding Brand
		brandLblPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		brandFieldPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
				
		brandLbl = new JLabel("Brand :");
		brandLblPanel.add(brandLbl);
		brandField = new JTextField();
		brandField.setPreferredSize(new Dimension(150, 25));
		brandFieldPanel.add(brandField);
		
		// pudding Size
		sizeLblPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		sizeFieldPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
						
		sizeLbl = new JLabel("Size :");
		sizeLblPanel.add(sizeLbl);
		sizeField = new JTextField();
		sizeField.setPreferredSize(new Dimension(150, 25));
		sizeFieldPanel.add(sizeField);
		
		// pudding Price
		priceLblPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		priceFieldPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
								
		priceLbl = new JLabel("Price :");
		priceLblPanel.add(priceLbl);
		priceField = new JTextField();
		priceField.setPreferredSize(new Dimension(150, 25));
		priceFieldPanel.add(priceField);
		
		formPanel.add(idLblPanel);
		formPanel.add(idFieldPanel);
		formPanel.add(nameLblPanel);
		formPanel.add(nameFieldPanel);
		formPanel.add(brandLblPanel);
		formPanel.add(brandFieldPanel);
		formPanel.add(sizeLblPanel);
		formPanel.add(sizeFieldPanel);
		formPanel.add(priceLblPanel);
		formPanel.add(priceFieldPanel);
		
		// Right Panel
		column = new Vector<Object>();
		column.add("ID");
		column.add("Name");
		column.add("Kode");
		column.add("Stock");
		column.add("Price");
		
		data = new Vector<Vector<Object>>();
		for (pudding pudding : puddingData) {
			row = new Vector<Object>();
			row.add(pudding.getId());
			row.add(pudding.getName());
			row.add(pudding.getKode());
			row.add(pudding.getStock());
			row.add(pudding.getPrice());
			data.add(row);
		}
		
		puddingTable = new JTable(data, column);
		puddingTable.addMouseListener(this);
		scrollPane = new JScrollPane(puddingTable);
		tablePanel = new JPanel();
		tablePanel.add(scrollPane);
		
		contentPanel.add(formPanel);
		contentPanel.add(tablePanel);
		
		midPanel.add(contentPanel);
		
		// Bot Panel
		botPanel = new JPanel(new GridLayout(2, 1));
		
		// Bottom Top Panel
		botTPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		
		addBtn = new JButton("Add");
		addBtn.addActionListener(this);
		updateBtn = new JButton("Update");
		updateBtn.addActionListener(this);
		deleteBtn = new JButton("Delete");
		deleteBtn.addActionListener(this);
		clearBtn = new JButton("Clear");
		clearBtn.addActionListener(this);
		
		botTPanel.add(addBtn);
		botTPanel.add(updateBtn);
		botTPanel.add(deleteBtn);
		botTPanel.add(clearBtn);
		
		// Bottom Bottom Panel
		botBPanel = new JPanel();
		backBtn = new JButton("Back");
		backBtn.addActionListener(this);
		botBPanel.add(backBtn);
		
		botPanel.add(botTPanel);
		botPanel.add(botBPanel);
		
		add(topPanel, BorderLayout.NORTH);
		add(midPanel, BorderLayout.CENTER);
		add(botPanel, BorderLayout.SOUTH);
	}
	
	void puddingFrame() {
		setTitle("Pudding");
		setSize(1140, 768);
		setVisible(true);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == addBtn) {
			String idStr = idField.getText();
			name = nameField.getText();
			kode = brandField.getText();
			stock = sizeField.getText();
			priceStr = priceField.getText();
			
			price = Integer.valueOf(priceStr);
			
			// Add pudding Data to Vector
			pudding addNewpudding = new pudding(0, name, kode, stock, price);
			puddingData.add(addNewpudding);
			
			// Add pudding to Database
			connectDb.insertpuddingData(name, kode, stock, price);
			
			puddingData.clear();
			setVisible(false);
			new Menu(puddingData, connectDb);
		}
		else if (e.getSource() == updateBtn) {
	
		}
		else if (e.getSource() == deleteBtn) {
	
		}
		else if (e.getSource() == clearBtn) {
			idField.setText("");
			nameField.setText("");
			brandField.setText("");
			sizeField.setText("");
			priceField.setText("");
		}
		else if (e.getSource() == backBtn) {
			puddingData.clear();
			setVisible(false);
			new Menu(puddingData, connectDb);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == puddingTable) {
			int row = puddingTable.getSelectedRow();
			idField.setText(puddingTable.getValueAt(row, 0).toString());
			nameField.setText(puddingTable.getValueAt(row, 1).toString());
			kodeField.setText(puddingTable.getValueAt(row, 2).toString());
			stockField.setText(puddingTable.getValueAt(row, 3).toString());
			priceField.setText(puddingTable.getValueAt(row, 4).toString());
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}